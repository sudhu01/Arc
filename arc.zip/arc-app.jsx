/* arc-app.jsx — Arc application shell: state, context, navigation, sheets. */

function inferTitle(entries, exById) {
  const count = {};
  entries.forEach(e => { const g = exById(e.exerciseId).group; count[g] = (count[g] || 0) + 1; });
  const top = Object.keys(count).sort((a, b) => count[b] - count[a])[0];
  return window.ArcData.DAY_TITLE[top] || 'Workout';
}

function Toast({ toast }) {
  if (!toast) return null;
  return (
    <div style={{
      position: 'absolute', left: '50%', bottom: 104, transform: `translateX(-50%) translateY(${toast.show ? 0 : 14}px)`,
      zIndex: 95, display: 'flex', alignItems: 'center', gap: 9, padding: '11px 18px',
      background: 'var(--toast-bg)', color: 'var(--toast-ink)', borderRadius: 999,
      boxShadow: '0 8px 28px rgba(0,0,0,0.28)', opacity: toast.show ? 1 : 0,
      transition: 'opacity .25s ease, transform .25s ease', fontWeight: 650, fontSize: 14.5,
      fontFamily: 'var(--font-display)', whiteSpace: 'nowrap',
    }}>
      <window.Icon name={toast.icon || 'check'} size={18} stroke={2.2} style={{ color: toast.icon === 'medal' ? 'var(--accent)' : 'var(--toast-ink)' }} />
      {toast.msg}
    </div>
  );
}

function BottomNav({ tab, setTab, onLog }) {
  const items = [
    { id: 'home', icon: 'home', label: 'Home' },
    { id: 'records', icon: 'trophy', label: 'Records' },
    { id: '__fab' },
    { id: 'calendar', icon: 'calendar', label: 'History' },
    { id: 'library', icon: 'dumbbell', label: 'Exercises' },
  ];
  return (
    <div style={{
      position: 'absolute', left: 0, right: 0, bottom: 0, zIndex: 70,
      paddingBottom: 22, paddingTop: 8,
      background: 'var(--nav-bg)', backdropFilter: 'blur(20px) saturate(180%)', WebkitBackdropFilter: 'blur(20px) saturate(180%)',
      borderTop: '1px solid var(--nav-line)',
      display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', alignItems: 'center',
    }}>
      {items.map(it => {
        if (it.id === '__fab') {
          return (
            <div key="fab" style={{ display: 'grid', placeItems: 'center' }}>
              <button onClick={onLog} aria-label="Log workout" style={{
                width: 56, height: 56, borderRadius: 20, marginTop: -30,
                background: 'var(--accent)', color: 'var(--accent-ink)', border: '4px solid var(--nav-bg)',
                display: 'grid', placeItems: 'center', cursor: 'pointer', boxShadow: 'var(--accent-shadow)',
                transition: 'transform .12s ease',
              }}
                onPointerDown={e => e.currentTarget.style.transform = 'scale(0.92)'}
                onPointerUp={e => e.currentTarget.style.transform = 'scale(1)'}
                onPointerLeave={e => e.currentTarget.style.transform = 'scale(1)'}
              ><window.Icon name="plus" size={26} stroke={2.6} /></button>
            </div>
          );
        }
        const active = tab === it.id;
        return (
          <button key={it.id} onClick={() => setTab(it.id)} style={{
            border: 'none', background: 'transparent', cursor: 'pointer',
            display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3,
            color: active ? 'var(--accent-strong)' : 'var(--nav-muted)', padding: '4px 0',
          }}>
            <window.Icon name={it.icon} size={23} stroke={active ? 2.4 : 2} fill={active && it.icon === 'home' ? 'currentColor' : 'none'} />
            <span style={{ fontSize: 10, fontWeight: active ? 700 : 600, fontFamily: 'var(--font-display)' }}>{it.label}</span>
          </button>
        );
      })}
    </div>
  );
}

function ArcApp({ theme, varOverrides }) {
  const D = window.ArcData;
  const [exercises, setExercises] = React.useState(() => D.EXERCISES.map(e => ({ ...e })));
  const [sessions, setSessions] = React.useState(() => D.buildSeed());
  const [tab, setTab] = React.useState('home');
  const [overlay, setOverlay] = React.useState({ type: null });
  const [toastState, setToastState] = React.useState(null);
  const toastTimer = React.useRef(null);

  const records = React.useMemo(() => D.computeRecords(sessions, exercises), [sessions, exercises]);
  const stats = React.useMemo(() => D.workoutStats(sessions), [sessions]);

  const exById = React.useCallback(id => exercises.find(e => e.id === id), [exercises]);
  const sessionForDate = React.useCallback(iso => sessions.find(s => s.date === iso) || null, [sessions]);
  const lastSetFor = React.useCallback(exId => {
    for (const s of sessions) { const e = s.entries.find(x => x.exerciseId === exId); if (e && e.sets.length) return e.sets[e.sets.length - 1]; }
    return null;
  }, [sessions]);

  const toast = (msg, icon) => {
    clearTimeout(toastTimer.current);
    setToastState({ msg, icon, show: false });
    requestAnimationFrame(() => requestAnimationFrame(() => setToastState({ msg, icon, show: true })));
    toastTimer.current = setTimeout(() => {
      setToastState(t => t ? { ...t, show: false } : null);
      setTimeout(() => setToastState(null), 300);
    }, 2300);
  };

  const addExercise = ({ name, group, unit }) => {
    const id = D.uid('ex');
    setExercises(es => [...es, { id, name, group, unit }]);
    return id;
  };

  const saveSession = (date, rawEntries) => {
    const before = records;
    const others = sessions.filter(s => s.date !== date);
    const existing = sessions.find(s => s.date === date);
    let next;
    if (!rawEntries.length) {
      next = others;
    } else {
      const session = {
        id: existing ? existing.id : D.uid('ses'), date,
        title: inferTitle(rawEntries, exById),
        entries: rawEntries.map(e => ({ id: D.uid('ent'), exerciseId: e.exerciseId, sets: e.sets.map(s => ({ id: D.uid('set'), weight: s.weight, reps: s.reps })) })),
      };
      next = [...others, session].sort((a, b) => b.date.localeCompare(a.date));
    }
    const after = D.computeRecords(next, exercises);
    let prName = null;
    for (const ex of exercises) {
      const b = before[ex.id] && before[ex.id].best, a = after[ex.id] && after[ex.id].best;
      if (a && b && a.score > b.score) { prName = ex.name; break; }
    }
    setSessions(next);
    if (prName) toast('New PR · ' + prName, 'medal');
    else if (!rawEntries.length) toast('Workout removed', 'trash');
    else toast('Workout saved', 'check');
  };

  const close = () => setOverlay({ type: null });
  const ctx = {
    exercises, sessions, records, stats, theme,
    exById, sessionForDate, lastSetFor, addExercise, saveSession, setTab,
    openPR: exId => setOverlay({ type: 'pr', exId }),
    openDay: date => setOverlay({ type: 'day', date }),
    openLog: (date, prefillExId) => setOverlay({ type: 'log', date: date || null, prefillExId }),
    openAddEx: () => setOverlay({ type: 'addex' }),
    close,
  };

  const Screen = { home: window.Dashboard, records: window.Records, calendar: window.Calendar, library: window.Library }[tab];

  return (
    <window.ArcCtx.Provider value={ctx}>
      <div style={{ position: 'relative', height: '100%', background: 'var(--bg)', color: 'var(--ink)', fontFamily: 'var(--font-body)', overflow: 'hidden', ...theme.cssVars, ...varOverrides }}>
        {/* top scrim under status bar */}
        <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 54, zIndex: 9, pointerEvents: 'none', background: 'linear-gradient(var(--bg), var(--bg) 55%, transparent)' }} />
        <div className="arc-scroll" style={{ position: 'absolute', inset: 0, overflowY: 'auto', overflowX: 'hidden', paddingTop: 56, paddingBottom: 120 }}>
          <Screen key={tab} />
        </div>

        <BottomNav tab={tab} setTab={setTab} onLog={() => ctx.openLog(null)} />
        <Toast toast={toastState} />

        <window.PRDetailSheet open={overlay.type === 'pr'} exId={overlay.exId} onClose={close} />
        <window.DayDetailSheet open={overlay.type === 'day'} date={overlay.date} onClose={close} />
        <window.LogSheet open={overlay.type === 'log'} date={overlay.date} prefillExId={overlay.prefillExId} onClose={close} />
        <window.AddExerciseSheet open={overlay.type === 'addex'} onClose={close} />
      </div>
    </window.ArcCtx.Provider>
  );
}

window.ArcApp = ArcApp;
