/* arc-charts.jsx — SVG charts for Arc. Exports to window. */

function useMeasure() {
  const ref = React.useRef(null);
  const [w, setW] = React.useState(0);
  React.useLayoutEffect(() => {
    if (!ref.current) return;
    const el = ref.current;
    const update = () => setW(el.clientWidth);
    update();
    const ro = new ResizeObserver(update);
    ro.observe(el);
    return () => ro.disconnect();
  }, []);
  return [ref, w];
}

// Smooth-ish line chart of 1RM / score over time, with area fill + last dot.
function LineChart({ data, height = 130, pad = 10, showDots = true, strokeW = 2.5, gradId }) {
  const [ref, w] = useMeasure();
  const gid = gradId || React.useMemo(() => 'g' + Math.random().toString(36).slice(2, 8), []);
  if (data.length === 0) return <div ref={ref} style={{ height }} />;
  const scores = data.map(d => d.score);
  let lo = Math.min(...scores), hi = Math.max(...scores);
  if (hi === lo) { hi += 1; lo -= 1; }
  const range = hi - lo;
  lo -= range * 0.18; hi += range * 0.18;
  const padL = pad, padR = pad, padT = 12, padB = 12;
  const innerW = Math.max(1, w - padL - padR);
  const innerH = height - padT - padB;
  const x = i => padL + (data.length === 1 ? innerW / 2 : (i / (data.length - 1)) * innerW);
  const y = v => padT + innerH - ((v - lo) / (hi - lo)) * innerH;

  // catmull-rom → bezier smoothing
  const pts = data.map((d, i) => [x(i), y(d.score)]);
  let line = '';
  if (pts.length === 1) { line = `M${pts[0][0]} ${pts[0][1]}`; }
  else {
    line = `M${pts[0][0]} ${pts[0][1]}`;
    for (let i = 0; i < pts.length - 1; i++) {
      const p0 = pts[i - 1] || pts[i], p1 = pts[i], p2 = pts[i + 1], p3 = pts[i + 2] || p2;
      const c1x = p1[0] + (p2[0] - p0[0]) / 6, c1y = p1[1] + (p2[1] - p0[1]) / 6;
      const c2x = p2[0] - (p3[0] - p1[0]) / 6, c2y = p2[1] - (p3[1] - p1[1]) / 6;
      line += ` C${c1x} ${c1y} ${c2x} ${c2y} ${p2[0]} ${p2[1]}`;
    }
  }
  const area = w ? `${line} L${x(data.length - 1)} ${padT + innerH} L${x(0)} ${padT + innerH} Z` : '';
  const last = pts[pts.length - 1];

  return (
    <div ref={ref} style={{ width: '100%' }}>
      {w > 0 && (
        <svg width={w} height={height} style={{ display: 'block', overflow: 'visible' }}>
          <defs>
            <linearGradient id={gid} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="var(--accent)" stopOpacity="0.28" />
              <stop offset="100%" stopColor="var(--accent)" stopOpacity="0" />
            </linearGradient>
          </defs>
          {[0.5].map((f, i) => (
            <line key={i} x1={padL} x2={w - padR} y1={padT + innerH * f} y2={padT + innerH * f}
              stroke="var(--line)" strokeWidth="1" strokeDasharray="2 5" />
          ))}
          <path d={area} fill={`url(#${gid})`} />
          <path d={line} fill="none" stroke="var(--accent)" strokeWidth={strokeW} strokeLinecap="round" strokeLinejoin="round" />
          {showDots && (
            <g>
              <circle cx={last[0]} cy={last[1]} r="6.5" fill="var(--accent)" opacity="0.18" />
              <circle cx={last[0]} cy={last[1]} r="3.6" fill="var(--surface)" stroke="var(--accent)" strokeWidth="2.5" />
            </g>
          )}
        </svg>
      )}
    </div>
  );
}

// Tiny inline sparkline (no axes), fixed box.
function Spark({ data, width = 64, height = 28, strokeW = 2 }) {
  if (!data || data.length === 0) return <svg width={width} height={height} />;
  const lo = Math.min(...data), hi = Math.max(...data) || 1;
  const rng = hi - lo || 1;
  const x = i => (data.length === 1 ? width / 2 : (i / (data.length - 1)) * (width - 4) + 2);
  const y = v => height - 3 - ((v - lo) / rng) * (height - 6);
  const d = data.map((v, i) => `${i === 0 ? 'M' : 'L'}${x(i).toFixed(1)} ${y(v).toFixed(1)}`).join(' ');
  return (
    <svg width={width} height={height} style={{ display: 'block', overflow: 'visible' }}>
      <path d={d} fill="none" stroke="currentColor" strokeWidth={strokeW} strokeLinecap="round" strokeLinejoin="round" />
      <circle cx={x(data.length - 1)} cy={y(data[data.length - 1])} r={2.6} fill="currentColor" />
    </svg>
  );
}

// Vertical bars (weekly volume).
function Bars({ data, height = 96, labels }) {
  const [ref, w] = useMeasure();
  const hi = Math.max(...data, 1);
  const gap = 8;
  const n = data.length;
  const bw = w ? (w - gap * (n - 1)) / n : 0;
  return (
    <div ref={ref} style={{ width: '100%' }}>
      {w > 0 && (
        <svg width={w} height={height + 18} style={{ display: 'block' }}>
          {data.map((v, i) => {
            const h = Math.max(3, (v / hi) * height);
            const xx = i * (bw + gap);
            const isLast = i === n - 1;
            return (
              <g key={i}>
                <rect x={xx} y={height - h} width={bw} height={h} rx={Math.min(7, bw / 2)}
                  fill={isLast ? 'var(--accent)' : 'var(--bar)'} />
                {labels && <text x={xx + bw / 2} y={height + 13} textAnchor="middle"
                  fontSize="10.5" fontFamily="var(--font-mono)" fill={isLast ? 'var(--accent-strong)' : 'var(--faint)'} fontWeight="600">{labels[i]}</text>}
              </g>
            );
          })}
        </svg>
      )}
    </div>
  );
}

Object.assign(window, { LineChart, Spark, Bars, useMeasure });
