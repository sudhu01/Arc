/* arc-data.js — seed data + helpers for Arc gym tracker.
   Exposes window.ArcData. Plain JS (no JSX). */
(function () {
  // ── Exercise library ─────────────────────────────────────────
  const EXERCISES = [
    { id: 'bench',    name: 'Bench Press',         group: 'Push', unit: 'lbs' },
    { id: 'ohp',      name: 'Overhead Press',      group: 'Push', unit: 'lbs' },
    { id: 'incline',  name: 'Incline DB Press',    group: 'Push', unit: 'lbs' },
    { id: 'deadlift', name: 'Deadlift',            group: 'Pull', unit: 'lbs' },
    { id: 'row',      name: 'Barbell Row',         group: 'Pull', unit: 'lbs' },
    { id: 'pullup',   name: 'Pull-Up',             group: 'Pull', unit: 'bw'  },
    { id: 'squat',    name: 'Back Squat',          group: 'Legs', unit: 'lbs' },
    { id: 'rdl',      name: 'Romanian Deadlift',   group: 'Legs', unit: 'lbs' },
  ];

  // ── Progression plan over 6 weeks (oldest → newest) ──────────
  const PLAN = {
    bench:    { day: 'Push', top: [155,160,165,170,175,180], make: t => [[t-20,8],[t-10,6],[t,5],[t,5]] },
    ohp:      { day: 'Push', top: [95,97.5,100,102.5,105,107.5], make: t => [[t-15,8],[t,6],[t,5]] },
    incline:  { day: 'Push', top: [55,57.5,60,62.5,65,67.5], make: t => [[t,10],[t,9],[t,8]] },
    deadlift: { day: 'Pull', top: [245,255,265,275,285,300], make: t => [[t-50,5],[t-25,4],[t,3]] },
    row:      { day: 'Pull', top: [135,140,145,150,155,160], make: t => [[t-15,10],[t,8],[t,8]] },
    pullup:   { day: 'Pull', reps: [[8,7,6],[9,8,6],[10,8,7],[10,9,7],[11,9,8],[12,10,8]] },
    squat:    { day: 'Legs', top: [205,215,225,235,245,255], make: t => [[t-30,6],[t-15,5],[t,5],[t,5]] },
    rdl:      { day: 'Legs', top: [155,160,165,170,175,180], make: t => [[t,8],[t,8],[t,8]] },
  };

  const DAY_TITLE = { Push: 'Push Day', Pull: 'Pull Day', Legs: 'Leg Day' };

  // ── Date helpers (parse/format as local, avoid TZ drift) ─────
  const TODAY = new Date(2026, 4, 29); // May 29 2026 (Fri)
  function iso(d) {
    return d.getFullYear() + '-' + String(d.getMonth()+1).padStart(2,'0') + '-' + String(d.getDate()).padStart(2,'0');
  }
  function parseISO(s) { const [y,m,d] = s.split('-').map(Number); return new Date(y, m-1, d); }
  function addDays(d, n) { const x = new Date(d); x.setDate(x.getDate()+n); return x; }

  let _uid = 1;
  const uid = (p) => (p||'id') + '_' + (_uid++);

  // ── Build the 18-session seed history ────────────────────────
  function buildSeed() {
    const WEEKS = 6;
    const sessions = [];
    for (let w = 0; w < WEEKS; w++) {
      // Friday of week w (newest week = WEEKS-1 lands on TODAY)
      const friday = addDays(TODAY, -(WEEKS - 1 - w) * 7);
      const dayDates = { Push: addDays(friday, -4), Pull: addDays(friday, -2), Legs: friday };
      for (const dayType of ['Push','Pull','Legs']) {
        const date = dayDates[dayType];
        const entries = [];
        for (const ex of EXERCISES) {
          const plan = PLAN[ex.id];
          if (plan.day !== dayType) continue;
          let sets;
          if (ex.unit === 'bw') {
            sets = plan.reps[w].map(r => ({ id: uid('set'), weight: 0, reps: r }));
          } else {
            sets = plan.make(plan.top[w]).map(([weight, reps]) => ({ id: uid('set'), weight, reps }));
          }
          entries.push({ id: uid('ent'), exerciseId: ex.id, sets });
        }
        sessions.push({ id: uid('ses'), date: iso(date), title: DAY_TITLE[dayType], entries });
      }
    }
    // newest first
    return sessions.sort((a,b) => b.date.localeCompare(a.date));
  }

  // ── Metrics ──────────────────────────────────────────────────
  function e1rm(weight, reps) { return weight <= 0 ? 0 : Math.round(weight * (1 + reps / 30)); }
  function setScore(ex, set) { return ex.unit === 'bw' ? set.reps : e1rm(set.weight, set.reps); }

  function sessionVolume(session) {
    let v = 0;
    for (const e of session.entries) for (const s of e.sets) v += (s.weight || 0) * s.reps;
    return v;
  }

  // Best record per exercise across all sessions.
  function computeRecords(sessions, exercises) {
    const byEx = {};
    for (const ex of exercises) byEx[ex.id] = { ex, best: null, history: [] };
    // walk oldest→newest so history is chronological
    const chrono = [...sessions].sort((a,b) => a.date.localeCompare(b.date));
    for (const ses of chrono) {
      for (const e of ses.entries) {
        const rec = byEx[e.exerciseId];
        if (!rec) continue;
        const ex = rec.ex;
        // best set this session
        let topSet = null, topScore = -1;
        for (const s of e.sets) {
          const sc = setScore(ex, s);
          if (sc > topScore) { topScore = sc; topSet = s; }
        }
        if (!topSet) continue;
        const point = { date: ses.date, score: topScore, weight: topSet.weight, reps: topSet.reps };
        rec.history.push(point);
        if (!rec.best || topScore > rec.best.score) {
          rec.best = { ...point };
        }
      }
    }
    return byEx;
  }

  function daysAgo(isoStr) {
    const d = parseISO(isoStr);
    return Math.round((TODAY - d) / 86400000);
  }

  function relDate(isoStr) {
    const n = daysAgo(isoStr);
    if (n === 0) return 'Today';
    if (n === 1) return 'Yesterday';
    if (n < 7) return n + ' days ago';
    if (n < 14) return 'Last week';
    return Math.floor(n / 7) + ' weeks ago';
  }

  const MONTHS = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  const WD = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
  function fmtDate(isoStr, opts) {
    const d = parseISO(isoStr);
    const wd = WD[d.getDay()], mo = MONTHS[d.getMonth()], day = d.getDate();
    if (opts === 'long') return wd + ', ' + mo + ' ' + day;
    return mo + ' ' + day;
  }

  // current streak = consecutive prior weeks (each with >=1 session) — simplified: count distinct
  // workout weeks ending this week.
  function workoutStats(sessions) {
    const total = sessions.length;
    const totalVol = sessions.reduce((a, s) => a + sessionVolume(s), 0);
    const totalSets = sessions.reduce((a, s) => a + s.entries.reduce((x, e) => x + e.sets.length, 0), 0);
    // sessions this calendar week (last 7 days)
    const thisWeek = sessions.filter(s => daysAgo(s.date) <= 6 && daysAgo(s.date) >= 0).length;
    return { total, totalVol, totalSets, thisWeek };
  }

  window.ArcData = {
    EXERCISES, DAY_TITLE, TODAY,
    buildSeed, e1rm, setScore, sessionVolume, computeRecords,
    daysAgo, relDate, fmtDate, parseISO, iso, addDays, workoutStats, uid,
    GROUPS: ['Push','Pull','Legs','Core'],
  };
})();
