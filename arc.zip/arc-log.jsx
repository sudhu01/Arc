/* arc-log.jsx — Log workout flow + Add exercise form. */

function AddExerciseForm({ onCreate, onCancel, submitLabel = 'Add exercise' }) {
  const D = window.ArcData;
  const [name, setName] = React.useState('');
  const [group, setGroup] = React.useState('Push');
  const [unit, setUnit] = React.useState('lbs');
  const valid = name.trim().length > 0;
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
      <div>
        <label style={lbl}>Exercise name</label>
        <window.TextInput value={name} onChange={setName} placeholder="e.g. Front Squat" autoFocus />
      </div>
      <div>
        <label style={lbl}>Muscle group</label>
        <window.Segmented options={D.GROUPS} value={group} onChange={setGroup} />
      </div>
      <div>
        <label style={lbl}>Tracking</label>
        <window.Segmented options={[{ value: 'lbs', label: 'Weight (lb)' }, { value: 'bw', label: 'Bodyweight' }]} value={unit} onChange={setUnit} />
      </div>
      <div style={{ display: 'flex', gap: 10, marginTop: 4 }}>
        {onCancel && <window.Btn variant="ghost" onClick={onCancel} style={{ flex: 1 }}>Cancel</window.Btn>}
        <window.Btn disabled={!valid} onClick={() => onCreate({ name: name.trim(), group, unit })} style={{ flex: 2 }} icon="check">{submitLabel}</window.Btn>
      </div>
    </div>
  );
}
const lbl = { display: 'block', fontSize: 12.5, fontWeight: 700, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: '0.04em', marginBottom: 8, marginLeft: 2 };

function SetRow({ index, set, unit, onChange, onDelete }) {
  const isBw = unit === 'bw';
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
      <div style={{ width: 22, textAlign: 'center', fontFamily: 'var(--font-mono)', fontSize: 13, fontWeight: 600, color: 'var(--faint)', flexShrink: 0 }}>{index + 1}</div>
      {!isBw && (
        <div style={{ flex: 1 }}><window.Stepper value={set.weight} step={5} suffix="lb" onChange={v => onChange({ ...set, weight: v })} /></div>
      )}
      <div style={{ flex: 1 }}><window.Stepper value={set.reps} step={1} min={1} suffix="reps" onChange={v => onChange({ ...set, reps: v })} /></div>
      <button onClick={onDelete} aria-label="Delete set" style={{
        border: 'none', background: 'transparent', color: 'var(--faint)', cursor: 'pointer',
        width: 34, height: 34, borderRadius: 999, display: 'grid', placeItems: 'center', flexShrink: 0,
      }}><window.Icon name="trash" size={17} stroke={1.9} /></button>
    </div>
  );
}

function LogSheet({ open, date, prefillExId, onClose }) {
  const { exercises, sessionForDate, lastSetFor, addExercise, saveSession, exById } = window.useArc();
  const D = window.ArcData;
  const [view, setView] = React.useState('log');
  const [draftDate, setDraftDate] = React.useState(D.iso(D.TODAY));
  const [entries, setEntries] = React.useState([]);
  const [query, setQuery] = React.useState('');

  const makeSet = (exId) => {
    const last = lastSetFor(exId);
    const ex = exById(exId);
    return { id: D.uid('set'), weight: ex.unit === 'bw' ? 0 : (last ? last.weight : 45), reps: last ? last.reps : 8 };
  };
  const addEntry = (exId) => {
    setEntries(es => [...es, { id: D.uid('ent'), exerciseId: exId, sets: [makeSet(exId)] }]);
    setView('log'); setQuery('');
  };

  React.useEffect(() => {
    if (!open) return;
    const d = date || D.iso(D.TODAY);
    setDraftDate(d);
    setView('log'); setQuery('');
    const existing = sessionForDate(d);
    if (existing) {
      setEntries(existing.entries.map(e => ({ id: D.uid('ent'), exerciseId: e.exerciseId, sets: e.sets.map(s => ({ id: D.uid('set'), weight: s.weight, reps: s.reps })) })));
    } else if (prefillExId) {
      setEntries([{ id: D.uid('ent'), exerciseId: prefillExId, sets: [makeSet(prefillExId)] }]);
    } else {
      setEntries([]);
    }
    // eslint-disable-next-line
  }, [open]);

  const updateEntry = (eid, fn) => setEntries(es => es.map(e => e.id === eid ? fn(e) : e));
  const totalSets = entries.reduce((a, e) => a + e.sets.length, 0);

  const save = () => {
    saveSession(draftDate, entries.map(e => ({ exerciseId: e.exerciseId, sets: e.sets.map(s => ({ weight: s.weight, reps: s.reps })) })));
    onClose();
  };

  const usedIds = new Set(entries.map(e => e.exerciseId));
  const filtered = exercises.filter(e => e.name.toLowerCase().includes(query.toLowerCase()));
  const byGroup = {};
  filtered.forEach(e => { (byGroup[e.group] = byGroup[e.group] || []).push(e); });

  const title = view === 'pick' ? 'Add Exercise' : view === 'new' ? 'New Exercise' : 'Log Workout';

  return (
    <window.Sheet open={open} onClose={onClose} title={title} full>
      {view === 'log' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16, minHeight: '100%' }}>
          {/* date selector */}
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', background: 'var(--surface-2)', borderRadius: 'var(--radius)', padding: '8px 10px' }}>
            <button onClick={() => setDraftDate(D.iso(D.addDays(D.parseISO(draftDate), -1)))} style={navDateBtn}><window.Icon name="chevL" size={20} stroke={2.4} /></button>
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 16.5, color: 'var(--ink)' }}>{D.fmtDate(draftDate, 'long')}</div>
              <div style={{ fontSize: 12, color: 'var(--muted)', fontWeight: 600 }}>{D.relDate(draftDate)}</div>
            </div>
            <button onClick={() => { const n = D.addDays(D.parseISO(draftDate), 1); if (n <= D.TODAY) setDraftDate(D.iso(n)); }}
              style={{ ...navDateBtn, opacity: draftDate >= D.iso(D.TODAY) ? 0.3 : 1 }}><window.Icon name="chevR" size={20} stroke={2.4} /></button>
          </div>

          {entries.length === 0 && (
            <div style={{ textAlign: 'center', padding: '26px 10px', color: 'var(--muted)' }}>
              <div style={{ color: 'var(--faint)', marginBottom: 10 }}><window.Icon name="dumbbell" size={36} stroke={1.6} /></div>
              <div style={{ fontSize: 14.5 }}>No exercises yet. Add your first one.</div>
            </div>
          )}

          {entries.map(e => {
            const ex = exById(e.exerciseId);
            return (
              <div key={e.id} style={{ border: '1px solid var(--line)', borderRadius: 'var(--radius)', padding: '14px', background: 'var(--surface)' }}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <window.GroupDot group={ex.group} />
                    <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 16.5, color: 'var(--ink)' }}>{ex.name}</span>
                  </div>
                  <button onClick={() => setEntries(es => es.filter(x => x.id !== e.id))} style={{ border: 'none', background: 'var(--surface-2)', color: 'var(--muted)', width: 30, height: 30, borderRadius: 999, display: 'grid', placeItems: 'center', cursor: 'pointer' }}>
                    <window.Icon name="x" size={16} stroke={2.2} />
                  </button>
                </div>
                <div style={{ display: 'flex', gap: 8, padding: '0 22px 6px', fontSize: 11, fontWeight: 700, color: 'var(--faint)', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
                  {ex.unit !== 'bw' && <div style={{ flex: 1, textAlign: 'center' }}>Weight</div>}
                  <div style={{ flex: 1, textAlign: 'center' }}>Reps</div>
                  <div style={{ width: 34, flexShrink: 0 }} />
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                  {e.sets.map((s, i) => (
                    <SetRow key={s.id} index={i} set={s} unit={ex.unit}
                      onChange={ns => updateEntry(e.id, en => ({ ...en, sets: en.sets.map(x => x.id === s.id ? ns : x) }))}
                      onDelete={() => updateEntry(e.id, en => ({ ...en, sets: en.sets.filter(x => x.id !== s.id) }))} />
                  ))}
                </div>
                <button onClick={() => updateEntry(e.id, en => ({ ...en, sets: [...en.sets, { ...makeSet(e.exerciseId), id: D.uid('set') }] }))}
                  style={{ marginTop: 10, width: '100%', border: '1px dashed var(--line)', background: 'transparent', color: 'var(--accent-strong)', borderRadius: 'var(--radius)', padding: '9px', fontSize: 13.5, fontWeight: 650, fontFamily: 'var(--font-display)', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}>
                  <window.Icon name="plus" size={16} stroke={2.4} /> Add set
                </button>
              </div>
            );
          })}

          <window.Btn variant="soft" full icon="plus" onClick={() => setView('pick')}>Add exercise</window.Btn>

          <div style={{ flex: 1 }} />
          <div style={{ position: 'sticky', bottom: 0, paddingTop: 6, background: 'linear-gradient(transparent, var(--surface) 30%)' }}>
            <window.Btn full size="lg" disabled={entries.length === 0} onClick={save} icon="check">
              Save workout{totalSets ? ` · ${totalSets} sets` : ''}
            </window.Btn>
          </div>
        </div>
      )}

      {view === 'pick' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, background: 'var(--surface-2)', borderRadius: 'var(--radius)', padding: '11px 14px' }}>
            <window.Icon name="search" size={18} stroke={2} style={{ color: 'var(--faint)' }} />
            <input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search exercises" autoFocus
              style={{ border: 'none', background: 'transparent', outline: 'none', flex: 1, fontSize: 16, color: 'var(--ink)', fontFamily: 'var(--font-display)' }} />
          </div>
          <window.Btn variant="ghost" full icon="plus" onClick={() => setView('new')}>Create new exercise</window.Btn>
          {D.GROUPS.filter(g => byGroup[g]).map(g => (
            <div key={g}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 7, margin: '4px 2px 8px' }}>
                <window.GroupDot group={g} /><span style={{ fontSize: 12.5, fontWeight: 700, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: '0.04em' }}>{g}</span>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 1, background: 'var(--line)', borderRadius: 'var(--radius)', overflow: 'hidden' }}>
                {byGroup[g].map(ex => (
                  <button key={ex.id} onClick={() => addEntry(ex.id)} style={{
                    border: 'none', textAlign: 'left', cursor: 'pointer', background: 'var(--surface)',
                    padding: '13px 15px', display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                    fontFamily: 'var(--font-display)', color: 'var(--ink)',
                  }}>
                    <span style={{ fontWeight: 600, fontSize: 15.5, opacity: usedIds.has(ex.id) ? 0.4 : 1 }}>{ex.name}</span>
                    {usedIds.has(ex.id)
                      ? <window.Icon name="check" size={18} stroke={2.4} style={{ color: 'var(--accent-strong)' }} />
                      : <window.Icon name="plus" size={18} stroke={2.4} style={{ color: 'var(--faint)' }} />}
                  </button>
                ))}
              </div>
            </div>
          ))}
          <window.Btn variant="quiet" full onClick={() => setView('log')}>Done</window.Btn>
        </div>
      )}

      {view === 'new' && (
        <AddExerciseForm submitLabel="Create & add"
          onCancel={() => setView('pick')}
          onCreate={({ name, group, unit }) => { const id = addExercise({ name, group, unit }); addEntry(id); }} />
      )}
    </window.Sheet>
  );
}
const navDateBtn = { border: 'none', background: 'var(--surface)', color: 'var(--ink)', width: 40, height: 40, borderRadius: 'var(--radius-sm)', display: 'grid', placeItems: 'center', cursor: 'pointer', boxShadow: 'var(--shadow-sm)' };

// App-level add-exercise sheet (from Library)
function AddExerciseSheet({ open, onClose }) {
  const { addExercise } = window.useArc();
  return (
    <window.Sheet open={open} onClose={onClose} title="New Exercise">
      <AddExerciseForm onCreate={({ name, group, unit }) => { addExercise({ name, group, unit }); onClose(); }} />
    </window.Sheet>
  );
}

window.LogSheet = LogSheet;
window.AddExerciseSheet = AddExerciseSheet;
window.AddExerciseForm = AddExerciseForm;
