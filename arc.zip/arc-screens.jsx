/* arc-screens.jsx — tab screens: Dashboard, Records, Calendar, Library. */

function SectionHead({ title, action, onAction }) {
  return (
    <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', gap: 10, margin: '0 2px 12px' }}>
      <h2 style={{ margin: 0, fontFamily: 'var(--font-display)', fontSize: 19, fontWeight: 700, letterSpacing: '-0.02em', color: 'var(--ink)', whiteSpace: 'nowrap' }}>{title}</h2>
      {action && <button onClick={onAction} style={{ border: 'none', background: 'transparent', color: 'var(--accent-strong)', fontWeight: 650, fontSize: 13.5, cursor: 'pointer', fontFamily: 'var(--font-display)', whiteSpace: 'nowrap', marginLeft: 10 }}>{action}</button>}
    </div>
  );
}

function Card({ children, style, onClick }) {
  return (
    <div onClick={onClick} style={{
      background: 'var(--surface)', border: '1px solid var(--card-line)', borderRadius: 'var(--radius-lg)',
      boxShadow: 'var(--shadow)', overflow: 'hidden', cursor: onClick ? 'pointer' : 'default', ...style,
    }}>{children}</div>
  );
}

// ── DASHBOARD ─────────────────────────────────────────────────────────
function Dashboard() {
  const { records, exercises, sessions, stats, openPR, openDay, setTab } = window.useArc();
  const D = window.ArcData;
  const hour = new Date().getHours();
  const greet = hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening';

  const lifts = ['bench', 'squat', 'deadlift'].filter(id => records[id] && records[id].history.length);
  const [sel, setSel] = React.useState(lifts[0] || (exercises[0] && exercises[0].id));
  const selRec = records[sel];
  const selHist = selRec ? selRec.history : [];
  const selDelta = selHist.length > 1 ? selHist[selHist.length - 1].score - selHist[selHist.length - 2].score : 0;

  // recent PRs
  const prList = exercises.map(e => records[e.id]).filter(r => r && r.best)
    .sort((a, b) => b.best.date.localeCompare(a.best.date)).slice(0, 5);
  const recent = sessions.slice(0, 4);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 24, padding: '4px 18px 0' }}>
      {/* greeting */}
      <div>
        <div style={{ fontSize: 13.5, color: 'var(--muted)', fontWeight: 600, marginBottom: 2 }}>{greet}</div>
        <h1 style={{ margin: 0, fontFamily: 'var(--font-display)', fontSize: 30, fontWeight: 700, letterSpacing: '-0.03em', color: 'var(--ink)', lineHeight: 1.05 }}>{D.fmtDate(D.iso(D.TODAY), 'long')}</h1>
      </div>

      {/* week stats */}
      <div style={{ display: 'flex', gap: 10 }}>
        <window.StatTile label="This week" value={stats.thisWeek + ''} sub="workouts" />
        <window.StatTile label="Volume" value={(stats.totalVol / 1000).toFixed(0) + 'k'} sub="lb all-time" />
        <window.StatTile label="Total sets" value={stats.totalSets + ''} />
      </div>

      {/* progress chart */}
      <Card style={{ padding: '16px 16px 10px' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 7 }}>
            <window.Icon name="trend" size={17} stroke={2.2} style={{ color: 'var(--accent-strong)' }} />
            <span style={{ fontWeight: 700, fontSize: 15, color: 'var(--ink)', whiteSpace: 'nowrap' }}>Strength progress</span>
          </div>
        </div>
        <window.Segmented options={lifts.map(id => ({ value: id, label: records[id].ex.name.split(' ')[0] }))} value={sel} onChange={setSel} style={{ marginBottom: 14 }} />
        {selRec && (
          <div onClick={() => openPR(sel)} style={{ cursor: 'pointer' }}>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginBottom: 2 }}>
              <span style={{ fontFamily: 'var(--font-mono)', fontWeight: 700, fontSize: 34, color: 'var(--ink)', fontVariantNumeric: 'tabular-nums', lineHeight: 1 }}>{selRec.best.score}</span>
              <span style={{ fontSize: 14, fontWeight: 650, color: 'var(--muted)' }}>lb est. 1RM</span>
              {selDelta > 0 && <span style={{ marginLeft: 'auto', display: 'inline-flex', alignItems: 'center', gap: 3, fontSize: 13, fontWeight: 700, color: 'var(--up)' }}><window.Icon name="arrowUp" size={13} stroke={2.6} />+{selDelta}</span>}
            </div>
            <window.LineChart data={selHist} height={120} />
          </div>
        )}
      </Card>

      {/* PRs */}
      <div>
        <SectionHead title="Personal records" action="See all" onAction={() => setTab('records')} />
        <div style={{ display: 'flex', gap: 12, overflowX: 'auto', padding: '2px 2px 12px', margin: '0 -18px', paddingLeft: 18, paddingRight: 18 }} className="arc-scroll-x">
          {prList.map(r => {
            const isBw = r.ex.unit === 'bw';
            const isNew = D.daysAgo(r.best.date) <= 16;
            return (
              <button key={r.ex.id} onClick={() => openPR(r.ex.id)} style={{
                flexShrink: 0, width: 158, textAlign: 'left', cursor: 'pointer',
                border: '1px solid var(--card-line)', background: 'var(--surface)', borderRadius: 'var(--radius-lg)',
                padding: '14px', boxShadow: 'var(--shadow)', display: 'flex', flexDirection: 'column', gap: 8,
              }}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <window.GroupDot group={r.ex.group} />
                  {isNew && <window.Tag>New</window.Tag>}
                </div>
                <div style={{ display: 'flex', alignItems: 'baseline', gap: 4 }}>
                  <span style={{ fontFamily: 'var(--font-mono)', fontWeight: 700, fontSize: 30, color: 'var(--ink)', fontVariantNumeric: 'tabular-nums', lineHeight: 1 }}>{isBw ? r.best.reps : r.best.score}</span>
                  <span style={{ fontSize: 13, fontWeight: 650, color: 'var(--muted)' }}>{isBw ? 'reps' : 'lb'}</span>
                </div>
                <div style={{ fontWeight: 650, fontSize: 13.5, color: 'var(--ink)', lineHeight: 1.2 }}>{r.ex.name}</div>
                <div style={{ color: 'var(--accent-strong)', marginTop: -2 }}><window.Spark data={r.history.map(h => h.score)} width={130} height={26} /></div>
                <div style={{ fontSize: 11.5, color: 'var(--faint)', fontWeight: 550 }}>{isBw ? `${r.best.reps} reps` : `${r.best.weight} × ${r.best.reps}`} · {D.relDate(r.best.date)}</div>
              </button>
            );
          })}
        </div>
      </div>

      {/* recent workouts */}
      <div>
        <SectionHead title="Recent workouts" action="History" onAction={() => setTab('calendar')} />
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {recent.map(ses => {
            const grp = ses.title.includes('Push') ? 'Push' : ses.title.includes('Pull') ? 'Pull' : 'Legs';
            const names = ses.entries.map(e => window.ArcData && exercises.find(x => x.id === e.exerciseId)).filter(Boolean);
            return (
              <Card key={ses.id} onClick={() => openDay(ses.date)} style={{ padding: '13px 15px', display: 'flex', alignItems: 'center', gap: 13 }}>
                <div style={{ width: 46, height: 46, borderRadius: 14, background: 'var(--surface-2)', display: 'grid', placeItems: 'center', flexShrink: 0 }}>
                  <div style={{ textAlign: 'center', lineHeight: 1 }}>
                    <div style={{ fontFamily: 'var(--font-mono)', fontWeight: 700, fontSize: 17, color: 'var(--ink)' }}>{D.parseISO(ses.date).getDate()}</div>
                    <div style={{ fontSize: 9.5, color: 'var(--muted)', fontWeight: 700, textTransform: 'uppercase', marginTop: 1 }}>{['Sun','Mon','Tue','Wed','Thu','Fri','Sat'][D.parseISO(ses.date).getDay()]}</div>
                  </div>
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 7, marginBottom: 2 }}>
                    <window.GroupDot group={grp} />
                    <span style={{ fontWeight: 700, fontSize: 15.5, color: 'var(--ink)', fontFamily: 'var(--font-display)' }}>{ses.title}</span>
                  </div>
                  <div style={{ fontSize: 12.5, color: 'var(--muted)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                    {names.map(n => n.name).join(' · ')}
                  </div>
                </div>
                <div style={{ textAlign: 'right', flexShrink: 0 }}>
                  <div style={{ fontFamily: 'var(--font-mono)', fontWeight: 600, fontSize: 13.5, color: 'var(--ink)' }}>{(D.sessionVolume(ses) / 1000).toFixed(1)}k</div>
                  <div style={{ fontSize: 10.5, color: 'var(--faint)', fontWeight: 600 }}>{D.relDate(ses.date)}</div>
                </div>
              </Card>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// ── RECORDS ───────────────────────────────────────────────────────────
function Records() {
  const { records, exercises, openPR } = window.useArc();
  const D = window.ArcData;
  const [filter, setFilter] = React.useState('All');
  const list = exercises.map(e => records[e.id]).filter(r => r && r.best)
    .filter(r => filter === 'All' || r.ex.group === filter)
    .sort((a, b) => (b.ex.unit === 'bw' ? 0 : b.best.score) - (a.ex.unit === 'bw' ? 0 : a.best.score));

  return (
    <div style={{ padding: '4px 18px 0' }}>
      <h1 style={titleStyle}>Records</h1>
      <window.Segmented options={['All', 'Push', 'Pull', 'Legs']} value={filter} onChange={setFilter} style={{ marginBottom: 18 }} />
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        {list.map((r, i) => {
          const isBw = r.ex.unit === 'bw';
          const isNew = D.daysAgo(r.best.date) <= 16;
          return (
            <Card key={r.ex.id} onClick={() => openPR(r.ex.id)} style={{ padding: '14px 16px', display: 'flex', alignItems: 'center', gap: 13 }}>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 7, marginBottom: 3 }}>
                  <window.GroupDot group={r.ex.group} />
                  <span style={{ fontWeight: 700, fontSize: 16, color: 'var(--ink)', fontFamily: 'var(--font-display)' }}>{r.ex.name}</span>
                  {isNew && <window.Tag>New</window.Tag>}
                </div>
                <div style={{ fontSize: 12.5, color: 'var(--muted)', fontWeight: 550 }}>{isBw ? `${r.best.reps} reps` : `${r.best.weight} lb × ${r.best.reps}`} · {D.relDate(r.best.date)}</div>
              </div>
              <div style={{ color: 'var(--accent-strong)' }}><window.Spark data={r.history.map(h => h.score)} width={56} height={26} /></div>
              <div style={{ textAlign: 'right', flexShrink: 0, minWidth: 56 }}>
                <div style={{ fontFamily: 'var(--font-mono)', fontWeight: 700, fontSize: 22, color: 'var(--ink)', fontVariantNumeric: 'tabular-nums', lineHeight: 1 }}>{isBw ? r.best.reps : r.best.score}</div>
                <div style={{ fontSize: 10.5, color: 'var(--faint)', fontWeight: 600, marginTop: 1 }}>{isBw ? 'reps' : 'est. 1RM'}</div>
              </div>
            </Card>
          );
        })}
      </div>
    </div>
  );
}

// ── CALENDAR ──────────────────────────────────────────────────────────
function Calendar() {
  const { sessions, sessionForDate, openDay } = window.useArc();
  const D = window.ArcData;
  const today = D.TODAY;
  const [ym, setYm] = React.useState({ y: today.getFullYear(), m: today.getMonth() });
  const first = new Date(ym.y, ym.m, 1);
  const startWd = first.getDay();
  const daysInMonth = new Date(ym.y, ym.m + 1, 0).getDate();
  const MONTHS = ['January','February','March','April','May','June','July','August','September','October','November','December'];

  const cells = [];
  for (let i = 0; i < startWd; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push(d);

  const monthSessions = sessions.filter(s => { const dt = D.parseISO(s.date); return dt.getFullYear() === ym.y && dt.getMonth() === ym.m; });
  const monthVol = monthSessions.reduce((a, s) => a + D.sessionVolume(s), 0);

  const prev = () => setYm(p => p.m === 0 ? { y: p.y - 1, m: 11 } : { y: p.y, m: p.m - 1 });
  const next = () => { const nm = ym.m === 11 ? { y: ym.y + 1, m: 0 } : { y: ym.y, m: ym.m + 1 }; if (new Date(nm.y, nm.m, 1) <= new Date(today.getFullYear(), today.getMonth(), 1)) setYm(nm); };
  const atCurrent = ym.y === today.getFullYear() && ym.m === today.getMonth();

  return (
    <div style={{ padding: '4px 18px 0' }}>
      <h1 style={titleStyle}>History</h1>
      <div style={{ display: 'flex', gap: 10, marginBottom: 18 }}>
        <window.StatTile label="Workouts" value={monthSessions.length + ''} sub="this month" />
        <window.StatTile label="Volume" value={(monthVol / 1000).toFixed(1) + 'k'} sub="lb lifted" />
      </div>
      <Card style={{ padding: '16px' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
          <button onClick={prev} style={navDateBtn2}><window.Icon name="chevL" size={18} stroke={2.4} /></button>
          <span style={{ fontWeight: 700, fontSize: 16.5, color: 'var(--ink)', fontFamily: 'var(--font-display)' }}>{MONTHS[ym.m]} {ym.y}</span>
          <button onClick={next} style={{ ...navDateBtn2, opacity: atCurrent ? 0.3 : 1 }}><window.Icon name="chevR" size={18} stroke={2.4} /></button>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: 2, marginBottom: 6 }}>
          {['S','M','T','W','T','F','S'].map((d, i) => <div key={i} style={{ textAlign: 'center', fontSize: 11, fontWeight: 700, color: 'var(--faint)' }}>{d}</div>)}
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: 2 }}>
          {cells.map((d, i) => {
            if (!d) return <div key={i} />;
            const iso = D.iso(new Date(ym.y, ym.m, d));
            const ses = sessionForDate(iso);
            const isToday = iso === D.iso(today);
            const future = new Date(ym.y, ym.m, d) > today;
            const grp = ses ? (ses.title.includes('Push') ? 'Push' : ses.title.includes('Pull') ? 'Pull' : 'Legs') : null;
            return (
              <button key={i} disabled={future} onClick={() => openDay(iso)} style={{
                aspectRatio: '1', border: isToday ? '1.5px solid var(--accent)' : '1.5px solid transparent',
                background: ses ? 'var(--surface-2)' : 'transparent', borderRadius: 12, cursor: future ? 'default' : 'pointer',
                display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 3, padding: 0,
                opacity: future ? 0.32 : 1,
              }}>
                <span style={{ fontSize: 13, fontWeight: ses ? 700 : 500, color: ses ? 'var(--ink)' : 'var(--muted)', fontFamily: 'var(--font-mono)' }}>{d}</span>
                <span style={{ width: 6, height: 6, borderRadius: 999, background: ses ? window.groupColor(grp) : 'transparent' }} />
              </button>
            );
          })}
        </div>
      </Card>
      <div style={{ display: 'flex', gap: 16, justifyContent: 'center', marginTop: 16 }}>
        {['Push', 'Pull', 'Legs'].map(g => (
          <div key={g} style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 12, color: 'var(--muted)', fontWeight: 600 }}>
            <window.GroupDot group={g} />{g}
          </div>
        ))}
      </div>
    </div>
  );
}

// ── LIBRARY ───────────────────────────────────────────────────────────
function Library() {
  const { exercises, records, sessions, openPR, openAddEx } = window.useArc();
  const D = window.ArcData;
  const [filter, setFilter] = React.useState('All');
  const trainCount = React.useMemo(() => {
    const c = {};
    sessions.forEach(s => s.entries.forEach(e => { c[e.exerciseId] = (c[e.exerciseId] || 0) + 1; }));
    return c;
  }, [sessions]);
  const list = exercises.filter(e => filter === 'All' || e.group === filter);

  return (
    <div style={{ padding: '4px 18px 0' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <h1 style={{ ...titleStyle, marginBottom: 0 }}>Exercises</h1>
        <window.Btn size="sm" variant="soft" icon="plus" onClick={openAddEx}>New</window.Btn>
      </div>
      <window.Segmented options={['All', 'Push', 'Pull', 'Legs']} value={filter} onChange={setFilter} style={{ margin: '16px 0 18px' }} />
      <div style={{ display: 'flex', flexDirection: 'column', gap: 1, background: 'var(--card-line)', borderRadius: 'var(--radius-lg)', overflow: 'hidden', border: '1px solid var(--card-line)' }}>
        {list.map(ex => {
          const r = records[ex.id];
          const best = r && r.best;
          const isBw = ex.unit === 'bw';
          return (
            <button key={ex.id} onClick={() => best && openPR(ex.id)} style={{
              border: 'none', textAlign: 'left', cursor: best ? 'pointer' : 'default', background: 'var(--surface)',
              padding: '15px 16px', display: 'flex', alignItems: 'center', gap: 12,
            }}>
              <window.GroupDot group={ex.group} size={10} />
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontWeight: 650, fontSize: 15.5, color: 'var(--ink)', fontFamily: 'var(--font-display)' }}>{ex.name}</div>
                <div style={{ fontSize: 12, color: 'var(--faint)', fontWeight: 550 }}>{ex.group} · trained {trainCount[ex.id] || 0}×</div>
              </div>
              {best && (
                <div style={{ textAlign: 'right' }}>
                  <div style={{ fontFamily: 'var(--font-mono)', fontWeight: 700, fontSize: 16, color: 'var(--ink)' }}>{isBw ? `${best.reps}` : best.score}</div>
                  <div style={{ fontSize: 10, color: 'var(--faint)', fontWeight: 600 }}>{isBw ? 'reps' : 'lb 1RM'}</div>
                </div>
              )}
              <window.Icon name="chevR" size={17} stroke={2.2} style={{ color: 'var(--faint)', flexShrink: 0 }} />
            </button>
          );
        })}
      </div>
    </div>
  );
}

const titleStyle = { margin: '0 0 16px', fontFamily: 'var(--font-display)', fontSize: 32, fontWeight: 700, letterSpacing: '-0.03em', color: 'var(--ink)' };
const navDateBtn2 = { border: 'none', background: 'var(--surface-2)', color: 'var(--ink)', width: 36, height: 36, borderRadius: 999, display: 'grid', placeItems: 'center', cursor: 'pointer' };

Object.assign(window, { Dashboard, Records, Calendar, Library, SectionHead, Card });
