/* arc-sheets.jsx — overlay sheets: PR detail, day detail, log flow, add exercise. */

function TextInput({ value, onChange, placeholder, autoFocus }) {
  return (
    <input value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder} autoFocus={autoFocus}
      style={{
        width: '100%', boxSizing: 'border-box', border: '1px solid var(--line)',
        background: 'var(--surface-2)', color: 'var(--ink)', borderRadius: 'var(--radius)',
        padding: '14px 16px', fontSize: 16.5, fontFamily: 'var(--font-display)', fontWeight: 550,
        outline: 'none',
      }}
      onFocus={e => e.target.style.borderColor = 'var(--accent)'}
      onBlur={e => e.target.style.borderColor = 'var(--line)'} />
  );
}

function GroupDot({ group, size = 9 }) {
  return <span style={{ width: size, height: size, borderRadius: 999, background: window.groupColor(group), flexShrink: 0, display: 'inline-block' }} />;
}

function Tag({ children, color, soft }) {
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 5, padding: '4px 9px', borderRadius: 999,
      fontSize: 11.5, fontWeight: 700, letterSpacing: '0.02em', textTransform: 'uppercase',
      fontFamily: 'var(--font-display)',
      background: soft || 'var(--accent-soft)', color: color || 'var(--accent-strong)',
    }}>{children}</span>
  );
}

function StatTile({ label, value, sub }) {
  return (
    <div style={{ flex: 1, background: 'var(--surface-2)', borderRadius: 'var(--radius)', padding: '13px 14px' }}>
      <div style={{ fontFamily: 'var(--font-mono)', fontWeight: 600, fontSize: 22, color: 'var(--ink)', fontVariantNumeric: 'tabular-nums', lineHeight: 1.1 }}>{value}</div>
      <div style={{ fontSize: 11.5, color: 'var(--muted)', fontWeight: 600, marginTop: 3, letterSpacing: '0.01em' }}>{label}</div>
      {sub && <div style={{ fontSize: 11, color: 'var(--faint)', marginTop: 1 }}>{sub}</div>}
    </div>
  );
}

// ── PR detail ─────────────────────────────────────────────────────────
function PRDetailSheet({ open, exId, onClose }) {
  const { records, exById, openLog } = window.useArc();
  const rec = exId ? records[exId] : null;
  const ex = rec && rec.ex;
  const D = window.ArcData;
  const isBw = ex && ex.unit === 'bw';
  const hist = rec ? rec.history : [];
  const best = rec && rec.best;
  const maxWeight = hist.length ? Math.max(...hist.map(h => h.weight)) : 0;
  const totalReps = hist.reduce((a, h) => a + h.reps, 0);
  const gain = hist.length > 1 ? hist[hist.length - 1].score - hist[0].score : 0;

  return (
    <window.Sheet open={open} onClose={onClose} title={ex ? ex.name : ''} full>
      {ex && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: -2 }}>
            <GroupDot group={ex.group} /><span style={{ fontSize: 13.5, color: 'var(--muted)', fontWeight: 600 }}>{ex.group}</span>
            <window.Tag>Personal Record</window.Tag>
          </div>

          {/* hero number */}
          <div style={{ background: 'var(--accent-soft)', borderRadius: 'var(--radius-lg)', padding: '20px 20px 16px' }}>
            <div style={{ fontSize: 12.5, color: 'var(--accent-strong)', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.06em' }}>{isBw ? 'Best Set' : 'Estimated 1RM'}</div>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginTop: 4 }}>
              <span style={{ fontFamily: 'var(--font-mono)', fontWeight: 700, fontSize: 52, color: 'var(--ink)', lineHeight: 1, fontVariantNumeric: 'tabular-nums' }}>
                {isBw ? best.reps : best.score}
              </span>
              <span style={{ fontSize: 18, fontWeight: 700, color: 'var(--accent-strong)' }}>{isBw ? 'reps' : 'lb'}</span>
            </div>
            <div style={{ fontSize: 14, color: 'var(--muted)', marginTop: 8, fontWeight: 550 }}>
              {isBw ? `${best.reps} reps` : `${best.weight} lb × ${best.reps}`} · {D.fmtDate(best.date, 'long')}
            </div>
          </div>

          {/* trend */}
          <div style={{ border: '1px solid var(--line)', borderRadius: 'var(--radius-lg)', padding: '14px 14px 8px', background: 'var(--surface)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 }}>
              <span style={{ fontSize: 13, fontWeight: 650, color: 'var(--ink)' }}>{isBw ? 'Reps over time' : '1RM over time'}</span>
              {gain > 0 && <span style={{ display: 'inline-flex', alignItems: 'center', gap: 3, fontSize: 12.5, fontWeight: 700, color: 'var(--up)' }}><window.Icon name="arrowUp" size={13} stroke={2.6} />+{gain} {isBw ? 'reps' : 'lb'}</span>}
            </div>
            <window.LineChart data={hist} height={140} />
          </div>

          {/* stats */}
          <div style={{ display: 'flex', gap: 10 }}>
            {!isBw && <StatTile label="Top weight" value={maxWeight + ''} sub="lb" />}
            <StatTile label="Sessions" value={hist.length + ''} />
            <StatTile label="Total reps" value={totalReps + ''} />
          </div>

          {/* progression log */}
          <div>
            <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: '0.04em', margin: '4px 2px 8px' }}>Progression</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 1, background: 'var(--line)', borderRadius: 'var(--radius)', overflow: 'hidden' }}>
              {[...hist].reverse().map((h, i) => {
                const isPR = h.score === best.score && h.date === best.date;
                return (
                  <div key={i} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '11px 14px', background: 'var(--surface)' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
                      <span style={{ fontSize: 13.5, color: 'var(--muted)', width: 64, fontWeight: 550 }}>{D.fmtDate(h.date)}</span>
                      <span style={{ fontFamily: 'var(--font-mono)', fontWeight: 600, fontSize: 14.5, color: 'var(--ink)' }}>{isBw ? `${h.reps} reps` : `${h.weight} × ${h.reps}`}</span>
                      {isPR && <window.Icon name="medal" size={15} stroke={1.8} style={{ color: 'var(--accent-strong)' }} />}
                    </div>
                    <span style={{ fontFamily: 'var(--font-mono)', fontSize: 13, color: 'var(--faint)', fontVariantNumeric: 'tabular-nums' }}>{isBw ? '' : h.score + ' 1RM'}</span>
                  </div>
                );
              })}
            </div>
          </div>

          <window.Btn full icon="plus" onClick={() => { onClose(); setTimeout(() => openLog(null, exId), 180); }}>Log {ex.name}</window.Btn>
        </div>
      )}
    </window.Sheet>
  );
}

// ── Day detail ────────────────────────────────────────────────────────
function DayDetailSheet({ open, date, onClose }) {
  const { sessionForDate, exById, openLog, records } = window.useArc();
  const D = window.ArcData;
  const ses = date ? sessionForDate(date) : null;
  return (
    <window.Sheet open={open} onClose={onClose} title={date ? D.fmtDate(date, 'long') : ''}>
      {ses ? (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <Tag>{ses.title}</Tag>
            <span style={{ fontSize: 13, color: 'var(--muted)', fontWeight: 550 }}>
              {ses.entries.reduce((a, e) => a + e.sets.length, 0)} sets · {D.sessionVolume(ses).toLocaleString()} lb volume
            </span>
          </div>
          {ses.entries.map(e => {
            const ex = exById(e.exerciseId);
            const isBw = ex.unit === 'bw';
            const best = records[ex.id] && records[ex.id].best;
            return (
              <div key={e.id} style={{ border: '1px solid var(--line)', borderRadius: 'var(--radius)', padding: '13px 15px', background: 'var(--surface)' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
                  <GroupDot group={ex.group} />
                  <span style={{ fontFamily: 'var(--font-display)', fontWeight: 650, fontSize: 16, color: 'var(--ink)' }}>{ex.name}</span>
                </div>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 7 }}>
                  {e.sets.map((s, i) => {
                    const isPR = best && !isBw && D.e1rm(s.weight, s.reps) >= best.score && s.date === undefined;
                    return (
                      <div key={s.id} style={{
                        display: 'inline-flex', alignItems: 'center', gap: 5, padding: '6px 11px', borderRadius: 'var(--radius-sm)',
                        background: 'var(--surface-2)', fontFamily: 'var(--font-mono)', fontWeight: 600, fontSize: 13.5, color: 'var(--ink)',
                      }}>
                        {isBw ? `${s.reps} reps` : `${s.weight} × ${s.reps}`}
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
          <window.Btn full variant="ghost" icon="pencil" onClick={() => { onClose(); setTimeout(() => openLog(date), 180); }}>Edit workout</window.Btn>
        </div>
      ) : (
        <div style={{ textAlign: 'center', padding: '20px 10px 8px' }}>
          <div style={{ color: 'var(--faint)', marginBottom: 14 }}><window.Icon name="dumbbell" size={40} stroke={1.6} /></div>
          <div style={{ fontWeight: 650, fontSize: 17, color: 'var(--ink)', marginBottom: 4 }}>Rest day</div>
          <div style={{ fontSize: 14, color: 'var(--muted)', marginBottom: 18 }}>No workout logged for this day.</div>
          <window.Btn full icon="plus" onClick={() => { onClose(); setTimeout(() => openLog(date), 180); }}>Log a workout</window.Btn>
        </div>
      )}
    </window.Sheet>
  );
}

window.PRDetailSheet = PRDetailSheet;
window.DayDetailSheet = DayDetailSheet;
window.TextInput = TextInput;
window.GroupDot = GroupDot;
window.Tag = Tag;
window.StatTile = StatTile;
