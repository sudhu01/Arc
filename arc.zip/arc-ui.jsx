/* arc-ui.jsx — shared primitives + icon set for Arc. Exports to window. */

// ── Icon set: simple, consistent stroke icons (24 grid) ───────────────
function Icon({ name, size = 24, stroke = 2, style, fill = 'none' }) {
  const common = {
    width: size, height: size, viewBox: '0 0 24 24', fill,
    stroke: 'currentColor', strokeWidth: stroke,
    strokeLinecap: 'round', strokeLinejoin: 'round', style,
  };
  const P = {
    home:      <path d="M3 11l9-7 9 7M5 10v9a1 1 0 001 1h3v-6h6v6h3a1 1 0 001-1v-9" />,
    trophy:    <g><path d="M7 4h10v5a5 5 0 01-10 0V4z" /><path d="M7 6H4v1a3 3 0 003 3M17 6h3v1a3 3 0 01-3 3" /><path d="M9 16h6M10 16v4M14 16v4M8 20h8" /></g>,
    calendar:  <g><rect x="3" y="5" width="18" height="16" rx="2.5" /><path d="M3 9h18M8 3v4M16 3v4" /></g>,
    dumbbell:  <g><path d="M2.5 9v6M5.5 7v10M18.5 7v10M21.5 9v6M5.5 12h13" /></g>,
    plus:      <path d="M12 5v14M5 12h14" />,
    minus:     <path d="M5 12h14" />,
    chevR:     <path d="M9 5l7 7-7 7" />,
    chevL:     <path d="M15 5l-7 7 7 7" />,
    chevD:     <path d="M5 9l7 7 7-7" />,
    x:         <path d="M6 6l12 12M18 6L6 18" />,
    trash:     <g><path d="M4 7h16M9 7V5a1 1 0 011-1h4a1 1 0 011 1v2M6 7l1 13a1 1 0 001 1h8a1 1 0 001-1l1-13" /></g>,
    pencil:    <path d="M16.5 4.5l3 3L8 19l-4 1 1-4L16.5 4.5z" />,
    check:     <path d="M5 13l4 4L19 7" />,
    flame:     <path d="M12 3c1 3-2 4-2 7a2 2 0 004 0c0-1 0-1.5-.5-2.5C16 9 17 12 17 14a5 5 0 01-10 0c0-4 3-6 5-11z" />,
    trend:     <path d="M3 17l6-6 4 4 8-8M21 7v5M21 7h-5" />,
    arrowUp:   <path d="M12 19V5M5 12l7-7 7 7" />,
    clock:     <g><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></g>,
    target:    <g><circle cx="12" cy="12" r="9" /><circle cx="12" cy="12" r="4.5" /><circle cx="12" cy="12" r="0.6" fill="currentColor" /></g>,
    search:    <g><circle cx="11" cy="11" r="7" /><path d="M21 21l-4-4" /></g>,
    layers:    <g><path d="M12 3l9 5-9 5-9-5 9-5zM3 14l9 5 9-5" /></g>,
    spark:     <path d="M12 3l2 6 6 .5-4.5 4 1.5 6L12 16l-5 3.5 1.5-6L4 9.5 10 9l2-6z" />,
    medal:     <g><circle cx="12" cy="15" r="6" /><path d="M9 9.5L6 3M15 9.5L18 3M12 13l.8 1.7 1.8.2-1.3 1.3.3 1.8-1.6-.9-1.6.9.3-1.8L9.4 14.9l1.8-.2L12 13z" /></g>,
  };
  return <svg {...common}>{P[name] || null}</svg>;
}

// ── Bottom sheet modal ────────────────────────────────────────────────
function Sheet({ open, onClose, children, title, full = false, dark }) {
  const [mounted, setMounted] = React.useState(open);
  const [shown, setShown] = React.useState(false);
  React.useEffect(() => {
    if (open) { setMounted(true); requestAnimationFrame(() => requestAnimationFrame(() => setShown(true))); }
    else { setShown(false); const t = setTimeout(() => setMounted(false), 280); return () => clearTimeout(t); }
  }, [open]);
  if (!mounted) return null;
  return (
    <div style={{ position: 'absolute', inset: 0, zIndex: 80, display: 'flex', flexDirection: 'column', justifyContent: 'flex-end' }}>
      <div onClick={onClose} style={{
        position: 'absolute', inset: 0, background: 'rgba(10,8,6,0.42)',
        opacity: shown ? 1 : 0, transition: 'opacity .28s ease', backdropFilter: 'blur(2px)',
      }} />
      <div style={{
        position: 'relative', background: 'var(--surface)', color: 'var(--ink)',
        borderTopLeftRadius: 30, borderTopRightRadius: 30,
        maxHeight: full ? 'calc(100% - 54px)' : '88%', minHeight: full ? 'calc(100% - 54px)' : 0,
        display: 'flex', flexDirection: 'column',
        transform: shown ? 'translateY(0)' : 'translateY(102%)',
        transition: 'transform .32s cubic-bezier(.32,.72,0,1)',
        boxShadow: '0 -10px 40px rgba(0,0,0,0.18)',
        overflow: 'hidden',
      }}>
        <div style={{ display: 'flex', justifyContent: 'center', paddingTop: 10 }}>
          <div style={{ width: 38, height: 5, borderRadius: 5, background: 'var(--line)' }} />
        </div>
        {title !== undefined && (
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '8px 18px 6px' }}>
            <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 21, letterSpacing: '-0.01em' }}>{title}</div>
            <button onClick={onClose} aria-label="Close" style={{
              border: 'none', background: 'var(--surface-2)', color: 'var(--muted)',
              width: 34, height: 34, borderRadius: 999, display: 'grid', placeItems: 'center', cursor: 'pointer',
            }}><Icon name="x" size={18} stroke={2.4} /></button>
          </div>
        )}
        <div style={{ overflowY: 'auto', WebkitOverflowScrolling: 'touch', flex: 1, padding: '4px 18px 26px' }} className="arc-scroll">
          {children}
        </div>
      </div>
    </div>
  );
}

// ── Buttons ───────────────────────────────────────────────────────────
function Btn({ children, onClick, variant = 'primary', size = 'md', full, disabled, style, icon }) {
  const pad = size === 'lg' ? '15px 22px' : size === 'sm' ? '8px 14px' : '12px 18px';
  const fs = size === 'lg' ? 17 : size === 'sm' ? 14 : 15.5;
  const variants = {
    primary: { background: 'var(--accent)', color: 'var(--accent-ink)', border: '1px solid transparent', boxShadow: 'var(--accent-shadow)' },
    soft:    { background: 'var(--accent-soft)', color: 'var(--accent-strong)', border: '1px solid transparent' },
    ghost:   { background: 'transparent', color: 'var(--ink)', border: '1px solid var(--line)' },
    quiet:   { background: 'var(--surface-2)', color: 'var(--ink)', border: '1px solid transparent' },
    danger:  { background: 'var(--danger-soft)', color: 'var(--danger)', border: '1px solid transparent' },
  };
  return (
    <button onClick={onClick} disabled={disabled} style={{
      display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 8,
      width: full ? '100%' : undefined, padding: pad, fontSize: fs,
      fontFamily: 'var(--font-display)', fontWeight: 650, letterSpacing: '-0.01em',
      borderRadius: 'var(--radius)', cursor: disabled ? 'default' : 'pointer',
      opacity: disabled ? 0.45 : 1, transition: 'transform .12s ease, filter .15s ease',
      ...variants[variant], ...style,
    }}
      onPointerDown={e => { if (!disabled) e.currentTarget.style.transform = 'scale(0.97)'; }}
      onPointerUp={e => e.currentTarget.style.transform = 'scale(1)'}
      onPointerLeave={e => e.currentTarget.style.transform = 'scale(1)'}
    >
      {icon && <Icon name={icon} size={size === 'lg' ? 20 : 18} stroke={2.2} />}
      {children}
    </button>
  );
}

// ── Segmented control ─────────────────────────────────────────────────
function Segmented({ options, value, onChange, style }) {
  return (
    <div style={{
      display: 'grid', gridTemplateColumns: `repeat(${options.length}, 1fr)`, gap: 3,
      background: 'var(--surface-2)', borderRadius: 'var(--radius)', padding: 3, ...style,
    }}>
      {options.map(o => {
        const v = typeof o === 'string' ? o : o.value;
        const label = typeof o === 'string' ? o : o.label;
        const active = v === value;
        return (
          <button key={v} onClick={() => onChange(v)} style={{
            border: 'none', cursor: 'pointer', padding: '9px 6px', borderRadius: 'calc(var(--radius) - 4px)',
            fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 13.5, letterSpacing: '-0.005em',
            background: active ? 'var(--surface)' : 'transparent',
            color: active ? 'var(--ink)' : 'var(--muted)',
            boxShadow: active ? 'var(--shadow-sm)' : 'none', transition: 'all .16s ease',
          }}>{label}</button>
        );
      })}
    </div>
  );
}

// ── Stepper (number field with +/-) ───────────────────────────────────
function Stepper({ value, onChange, step = 5, min = 0, max = 9999, suffix }) {
  const set = v => onChange(Math.max(min, Math.min(max, v)));
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 0, background: 'var(--surface-2)', borderRadius: 'var(--radius)', overflow: 'hidden' }}>
      <button onClick={() => set(value - step)} style={stepBtn}><Icon name="minus" size={18} stroke={2.6} /></button>
      <div style={{ flex: 1, textAlign: 'center', fontFamily: 'var(--font-mono)', fontWeight: 600, fontSize: 19, fontVariantNumeric: 'tabular-nums', color: 'var(--ink)' }}>
        {value}{suffix ? <span style={{ fontSize: 12, color: 'var(--muted)', marginLeft: 3 }}>{suffix}</span> : null}
      </div>
      <button onClick={() => set(value + step)} style={stepBtn}><Icon name="plus" size={18} stroke={2.6} /></button>
    </div>
  );
}
const stepBtn = {
  border: 'none', background: 'transparent', color: 'var(--ink)', cursor: 'pointer',
  width: 46, height: 46, display: 'grid', placeItems: 'center', flexShrink: 0,
};

// ── Group dot color ───────────────────────────────────────────────────
const GROUP_HUE = { Push: 28, Pull: 255, Legs: 150, Core: 320 };
function groupColor(group) { return `oklch(0.68 0.15 ${GROUP_HUE[group] ?? 28})`; }

// ── App context (state + actions, provided by ArcApp) ─────────────────
const ArcCtx = React.createContext(null);
const useArc = () => React.useContext(ArcCtx);

Object.assign(window, { Icon, Sheet, Btn, Segmented, Stepper, groupColor, GROUP_HUE, ArcCtx, useArc });
